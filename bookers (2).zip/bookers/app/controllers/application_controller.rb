class ApplicationController < ActionController::Base
  protect_from_forgery
  def show
  end

  def index
  end

  def new
  end

  def create
    @book = Book.new(list_params)
    if @book.save
      redirect_to book_path(@book.id)
    else
      render :new
    end
  end

  def edit
  end

end
